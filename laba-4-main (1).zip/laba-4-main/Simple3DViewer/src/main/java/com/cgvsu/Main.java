package com.cgvsu;

import com.cgvsu.Math.Matrix3f;
import com.cgvsu.Math.Vector3f;
import com.cgvsu.render_engine.GraphicConveyor;

public class Main {
    public static void main(String[] args) {
        Simple3DViewer.main(args);
    }
}
